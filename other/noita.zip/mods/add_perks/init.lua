ModLuaFileAppend("data/scripts/perks/perk_list.lua", "data/scripts/add_perks_list.lua")

function OnModPreInit()
	print("Mod - OnModPreInit()")
end

function OnModInit()
	print("Mod - OnModInit()")
end

function OnModPostInit()
	print("Mod - OnModPostInit()")
end

dofile_once("data/scripts/lib/utilities.lua")
dofile_once("data/scripts/perks/perk.lua")
function OnPlayerSpawned(player_entity)
    local x, y = EntityGetTransform(player_entity)
	
    local perk = perk_spawn(x, y, "EDIT_WANDS_EVERYWHERE")
    perk_pickup(perk, player_entity, EntityGetName(perk), false, false)
	
	local perk = perk_spawn(x, y, "LIFE_REGENERATION_PASSIVE")
    perk_pickup(perk, player_entity, EntityGetName(perk), false, false)
	
	local perk = perk_spawn(x, y, "PROTECTION_TOTAL")
    perk_pickup(perk, player_entity, EntityGetName(perk), false, false)
	
	local perk = perk_spawn(x, y, "PLASMA_SHIELD")
    perk_pickup(perk, player_entity, EntityGetName(perk), false, false)

    GamePrint("Additional Perks -> Active")
end

print("Additional Perks.")


--[[

    local perk = perk_spawn(x, y, "LIFE_REGENERATION_PASSIVE")
    perk_pickup(perk, player_entity, EntityGetName(perk), false, false)
	
    local perk = perk_spawn(x, y, "EDIT_WANDS_EVERYWHERE")
    perk_pickup(perk, player_entity, EntityGetName(perk), false, false)

    local perk = perk_spawn(x, y, "PROTECTION_ALL")
    perk_pickup(perk, player_entity, EntityGetName(perk), false, false)

    local perk = perk_spawn(x, y, "PROTECTION_FIRE")
    perk_pickup(perk, player_entity, EntityGetName(perk), false, false)
	
    local perk = perk_spawn(x, y, "PROTECTION_FREEZE")
    perk_pickup(perk, player_entity, EntityGetName(perk), false, false)	

    local perk = perk_spawn(x, y, "PROTECTION_RADIOACTIVITY")
    perk_pickup(perk, player_entity, EntityGetName(perk), false, false)

    local perk = perk_spawn(x, y, "PROTECTION_EXPLOSION")
    perk_pickup(perk, player_entity, EntityGetName(perk), false, false)

    local perk = perk_spawn(x, y, "PROTECTION_MELEE")
    perk_pickup(perk, player_entity, EntityGetName(perk), false, false)

    local perk = perk_spawn(x, y, "PROTECTION_ELECTRICITY")
    perk_pickup(perk, player_entity, EntityGetName(perk), false, false)

    local perk = perk_spawn(x, y, "SHIELD")
    perk_pickup(perk, player_entity, EntityGetName(perk), false, false)
	
]]--