local player_entity = EntityGetClosestWithTag( x, y, "player_unit")

local models = EntityGetComponent( player_entity, "DamageModelComponent" )
if( models ~= nil ) then
	for i,model in ipairs(models) do
	
		local hp = tonumber( ComponentGetValue( model, "hp" ) )
		local max_hp = tonumber( ComponentGetValue( model, "max_hp" ) )
		
		--local value = 1/25;
		local k = 10;
		local value = k*(max_hp/100);
		
		if ( hp < max_hp ) then
			--GamePrint("+" .. tostring(value*25))
			ComponentSetValue( model, "hp", hp + value )			
		end			
	end
end



