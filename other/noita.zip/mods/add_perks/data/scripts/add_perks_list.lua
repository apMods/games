table.insert(perk_list,
  {
    id = "LIFE_REGENERATION_PASSIVE",
    ui_name = "Life Regeneration",
    ui_description = "Slowly recovers your life",
    ui_icon = "data/ui_gfx/life_regeneration_passive.png",
    perk_icon = "data/ui_gfx/life_regeneration_passive.png",
    game_effect = "",
    usable_by_enemies = false,
    not_in_default_perk_pool = true,
	
	func = function( entity_perk_item, entity_who_picked, item_name )
	
		EntityAddComponent( entity_who_picked, "LuaComponent", 
			{
				_tags = "perk_component",
				script_source_file = "data/scripts/life_regeneration.lua",
				execute_every_n_frame = "60",
			}
		)	

	end,
  }  
)

table.insert(perk_list,
  {
    id = "PROTECTION_TOTAL",
    ui_name = "Total Protection",
    ui_description = "Protects you from all kinds of damage",
	ui_icon = "data/ui_gfx/perk_icons/protection_melee.png",
	perk_icon = "data/items_gfx/perks/protection_melee.png",
    game_effect = "PROTECTION_ALL",
    usable_by_enemies = false,
    not_in_default_perk_pool = true,
	
	func = function( entity_perk_item, entity_who_picked, item_name )
	
		local x,y = EntityGetTransform( entity_who_picked )
		local child_id = EntityLoad( "data/scripts/polymorph_field.xml", x, y )
		EntityAddTag( child_id, "perk_entity" )
		EntityAddChild( entity_who_picked, child_id )
	
	end,
  }  
)

table.insert(perk_list,
  {
	id = "PLASMA_SHIELD",
	ui_name = "Plasma Shield",
	ui_description = "Protects you from enemy projectiles",
	ui_icon = "data/ui_gfx/perk_icons/shield.png",
	perk_icon = "data/items_gfx/perks/shield.png",
	usable_by_enemies = false,
	func = function( entity_perk_item, entity_who_picked, item_name )
		local x,y = EntityGetTransform( entity_who_picked )
		local child_id = EntityLoad( "data/scripts/plasma_shield.xml", x, y )
		EntityAddTag( child_id, "perk_entity" )
		EntityAddChild( entity_who_picked, child_id )
	end,
  }  
)