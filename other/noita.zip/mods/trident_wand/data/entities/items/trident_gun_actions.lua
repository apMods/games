table.insert(actions,
	{
		id          = "HELL_BULLET",
		name 		= "Hell Bullet",
		description = "Damage from Hell",
		sprite 		= "data/items_gfx/hell_bullet.png",
		sprite_unidentified = "data/ui_gfx/gun_actions/light_bullet_unidentified.png",
		related_projectiles	= {"data/entities/items/hell_bullet.xml"},
		type 		= ACTION_TYPE_PROJECTILE,
		spawn_level                       = "0,0,0", -- LIGHT_BULLET
		spawn_probability                 = "0,0,0", -- LIGHT_BULLET
		price = 100,
		mana = 0,
		--max_uses = -1,
		action 		= function()
			add_projectile("data/entities/items/hell_bullet.xml")
			c.extra_entities = c.extra_entities .. "data/entities/misc/light.xml,"
			
			--local k = 1
			--c.damage_projectile_add = c.damage_projectile_add + 100
			--c.damage_projectile_add = c.damage_projectile_add * k
			--c.fire_rate_wait = c.fire_rate_wait + 7
			--c.spread_degrees = c.spread_degrees - 1.0
			--c.damage_critical_chance = c.damage_critical_chance + 5
		end,
	}
)