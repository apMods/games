dofile("data/scripts/lib/utilities.lua")
dofile("data/scripts/gun/procedural/gun_action_utils.lua")

local entity_id = GetUpdatedEntityID()

--AddGunActionPermanent(entity_id,"LASER_LUMINOUS_DRILL")
--AddGunActionPermanent(entity_id,"HELL_BULLET")
--AddGunActionPermanent(entity_id,"ENERGY_SHIELD_SECTOR")
--AddGunActionPermanent(entity_id,"ENERGY_SHIELD")