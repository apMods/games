--[[
No need to mod any of this
]]--

function OnModPreInit()
	print("Mod - OnModPreInit()")
end

function OnModInit()
	print("Mod - OnModInit()")
end

function OnModPostInit()
	print("Mod - OnModPostInit()")
end

function OnPlayerSpawned( player_entity )
	GamePrint("Trident Wand -> Active")
end


ModLuaFileAppend("data/scripts/gun/gun_actions.lua", "data/entities/items/trident_gun_actions.lua")
print("Trident Wand.")