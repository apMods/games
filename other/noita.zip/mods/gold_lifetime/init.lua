--[[
No need to mod any of this
]]--

function OnModPreInit()
	print("Mod - OnModPreInit()")
end

function OnModInit()
	print("Mod - OnModInit()")
end

function OnModPostInit()
	print("Mod - OnModPostInit()")
end

function OnPlayerSpawned( player_entity )
	GamePrint("Gold Lifetime -> Active")
end

print("Gold Lifetime.")