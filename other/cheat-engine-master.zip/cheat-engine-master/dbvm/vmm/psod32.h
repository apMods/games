/*
 * psod32.h
 *
 *  Created on: Feb 28, 2018
 *      Author: root
 */

#ifndef VMM_PSOD32_H_
#define VMM_PSOD32_H_

int PSOD32BitHandler();

#endif /* VMM_PSOD32_H_ */
