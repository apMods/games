/*
 * speedhack.h
 *
 *  Created on: Aug 28, 2013
 *      Author: eric
 */

#ifndef SPEEDHACK_H_
#define SPEEDHACK_H_

int speedhack_initializeSpeed(float speed);

#endif /* SPEEDHACK_H_ */
