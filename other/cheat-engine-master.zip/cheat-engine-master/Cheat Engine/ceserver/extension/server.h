/*
 * server.h
 *
 *  Created on: Aug 25, 2013
 *      Author: eric
 */

#ifndef SERVER_H_
#define SERVER_H_

#define EXTCMD_ALLOC                   0
#define EXTCMD_FREE                    1
#define EXTCMD_CREATETHREAD            2
#define EXTCMD_LOADMODULE              3
#define EXTCMD_SPEEDHACK_SETSPEED      4
//#define EXTCMD_CHANGEMEMORYPROTECTION  5


#endif /* SERVER_H_ */
