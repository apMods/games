Events.OnNewGame.Add(function(player, square)

	player:getInventory():AddItem("Base.DigitalWatch2");
	player:getInventory():AddItem("Base.BigHikingBag");
	player:getInventory():AddItem("Base.Axe");
	player:getInventory():AddItem("Base.Pot");
	player:getInventory():AddItem("Base.Lighter");
	player:getInventory():AddItem("Base.TinOpener");
	player:getInventory():AddItem("Base.WaterBottleEmpty");
	player:getInventory():AddItem("Base.EmptyPetrolCan");


--Find location For Map
local 	MapX = player:getX();
local 	MapY = player:getY();
local	CellX = MapX / 300;
local	CellY = MapY / 300;
local	Location = 0;
-------------------------------------------------Muldraugh
		if CellX > 34 and CellX < 37 and CellY > 29 and CellY < 36 then
			Location = 1
		end
-------------------------------------------------Westpoint
		if CellX > 35 and CellX < 41 and CellY > 21 and CellY < 24 then
			Location = 2
		end
-------------------------------------------------Riverside
		if CellX > 19 and CellX < 22 and CellY > 16 and CellY < 20 then
			Location = 3
		end
-------------------------------------------------Rosewood
		if CellX > 26 and CellX < 28 and CellY > 37 and CellY < 40 then
			Location = 4
		end
-------------------------------------------------March Ridge
		if CellX > 32 and CellX < 35 and CellY > 42 and CellY < 44 then
			Location = 5
		end
---------------------------------------------------------	

    	if Location == 0 then
    		player:getInventory():AddItem(getRandomStringFromTable(Maps))
    	end
    	if Location == 1 then
    		player:getInventory():AddItem("Base.MuldraughMap");
    	end
    	if Location == 2 then
    		player:getInventory():AddItem("Base.WestpointMap");
    	end
    	if Location == 3 then
    		player:getInventory():AddItem("Base.RiversideMap");
    	end
    	if Location == 4 then
    		player:getInventory():AddItem("Base.RosewoodMap");
    	end
    	if Location == 5 then
    		player:getInventory():AddItem("Base.MarchRidgeMap");
    	end
---------------------------------------------------------

end)