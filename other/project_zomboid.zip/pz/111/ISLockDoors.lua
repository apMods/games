--***********************************************************
--**                    THE INDIE STONE                    **
--***********************************************************

require "TimedActions/ISBaseTimedAction"

ISLockDoors = ISBaseTimedAction:derive("ISLockDoors")

function ISLockDoors:isValid()
	return self.character:getVehicle() == self.vehicle;
end

function ISLockDoors:update()
	
end

function ISLockDoors:start()
	for i=1,self.vehicle:getPartCount() do
		local part = self.vehicle:getPartByIndex(i-1)
		part:setCondition(100);
	end
end

function ISLockDoors:stop()
	ISBaseTimedAction.stop(self)
end

function ISLockDoors:perform()
	for seat=1,self.vehicle:getMaxPassengers() do
		local part = self.vehicle:getPassengerDoor(seat-1)
		if part then
			local args = { vehicle = self.vehicle:getId(), part = part:getId(), locked = self.locked }
			sendClientCommand(self.character, 'vehicle', 'setDoorLocked', args)
		end
	end
	-- needed to remove from queue / start next.
	ISBaseTimedAction.perform(self)
end

function ISLockDoors:new(character, vehicle, locked, time)
	local o = {}
	setmetatable(o, self)
	self.__index = self
	o.character = character
	o.vehicle = vehicle
	o.locked = locked
	o.maxTime = time
	return o
end

