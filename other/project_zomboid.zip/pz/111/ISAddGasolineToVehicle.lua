--***********************************************************
--**                    THE INDIE STONE                    **
--***********************************************************

require "TimedActions/ISBaseTimedAction"

ISAddGasolineToVehicle = ISBaseTimedAction:derive("ISAddGasolineToVehicle")

function ISAddGasolineToVehicle:isValid()
--	return self.vehicle:isInArea(self.part:getArea(), self.character)
	return true;
end

function ISAddGasolineToVehicle:update()

end

function ISAddGasolineToVehicle:start()
	self.part:setContainerContentAmount(self.part:getContainerCapacity())
	self.action:setTime(1)
end

function ISAddGasolineToVehicle:stop()
	self.item:setJobDelta(0)
	ISBaseTimedAction.stop(self)
end

function ISAddGasolineToVehicle:perform()

end

function ISAddGasolineToVehicle:new(character, part, item, time)
	local o = {}
	setmetatable(o, self)
	self.__index = self
	o.character = character
	o.vehicle = part:getVehicle()
	o.part = part
	o.item = item
	o.maxTime = time
	return o
end

