function SpawnPoints()
    return {
        unemployed = {
            {worldX=14, worldY=24, posX=42, posY=42}, -- camp
        },
    }
end
