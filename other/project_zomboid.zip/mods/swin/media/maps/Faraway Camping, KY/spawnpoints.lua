function SpawnPoints()
    return {
        unemployed = {
            {worldX=12, worldY=19, posX=30, posY=30}, -- camp
        },
    }
end
