--***********************************************************
--**                    THE INDIE STONE                    **
--***********************************************************

require "TimedActions/ISBaseTimedAction"

ISOpenMechanicsUIAction = ISBaseTimedAction:derive("ISOpenMechanicsUIAction")

function ISOpenMechanicsUIAction:isValid()
	return true;
end

function ISOpenMechanicsUIAction:waitToStart()
	if self.character:getVehicle() then return false end
	self.character:faceThisObject(self.vehicle)
	return self.character:shouldBeTurning()
end

function ISOpenMechanicsUIAction:update()
	self.character:faceThisObject(self.vehicle)
end

function ISOpenMechanicsUIAction:start()

	-----------------------------------------------------------------------------------------------
	------------------------------ Fix car parts ----------------------------------------------
	for i=1,self.vehicle:getPartCount() do
		local part = self.vehicle:getPartByIndex(i-1)
		part:setCondition(100);
		part:setContainerContentAmount(part:getContainerCapacity()); -- tires + gas
	end

	------------------------------ Open doors (excluding trunk door) --------------------------
	for seat=1,self.vehicle:getMaxPassengers() do
		local part = self.vehicle:getPassengerDoor(seat-1)
		if part then
			local args = { vehicle = self.vehicle:getId(), part = part:getId(), locked = false }
			sendClientCommand(self.character, 'vehicle', 'setDoorLocked', args)
		end
	end

	------------------------------ Hotwire ignition -------------------------------------------
	if self.vehicle:getCurrentKey() == nil and (not self.vehicle:isHotwired())
	then
		self.vehicle:setHotwired(true);
	end

	-----------------------------------------------------------------------------------------------

	self:setActionAnim("ExamineVehicle");
	self:setOverrideHandModels(nil, nil)
end

function ISOpenMechanicsUIAction:stop()
	ISBaseTimedAction.stop(self)
end

function ISOpenMechanicsUIAction:perform()
	local ui = getPlayerMechanicsUI(self.character:getPlayerNum());
	ui.vehicle = self.vehicle;
	ui.usedHood = self.usedHood
	ui:initParts();
	ui:setVisible(true, JoypadState.players[self.character:getPlayerNum()+1])
	ui:addToUIManager()
	-- needed to remove from queue / start next.
	ISBaseTimedAction.perform(self)
end

function ISOpenMechanicsUIAction:new(character, vehicle, usedHood)
	local o = {}
	setmetatable(o, self)
	self.__index = self
	o.character = character
	o.vehicle = vehicle
	o.usedHood = usedHood
	o.maxTime = 200 - (character:getPerkLevel(Perks.Mechanics) * (200/15));
	if vehicle:getScript() and vehicle:getScript():getWheelCount() == 0 then
		o.maxTime = 1
	end
	local cheat = getCore():getDebug() and getDebugOptions():getBoolean("Cheat.Vehicle.MechanicsAnywhere")
	if ISVehicleMechanics.cheat or cheat or character:isTimedActionInstant() then
		o.maxTime = 1
	end
	return o
end

