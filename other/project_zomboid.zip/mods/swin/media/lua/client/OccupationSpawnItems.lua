Events.OnNewGame.Add(function(player, square)


	player:getInventory():AddItem("Swin.Backpack");
	player:getInventory():AddItem("Swin.WatchBlack");

	player:getInventory():AddItem("Swin.Suit");
	player:getInventory():AddItem("Swin.Helmet");
	player:getInventory():AddItem("Swin.Boots");
	player:getInventory():AddItem("Swin.Gloves");

	player:getInventory():AddItem("Swin.Axe");

	player:getInventory():AddItem("Base.WaterBottleEmpty");


end)