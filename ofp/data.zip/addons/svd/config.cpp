// Class definitions

class CfgPatches
{

	class SVD
	{
		units[] = { "" };
		weapons[] = { "SVD" };
		requiredVersion = 1.26;
	};
};

class CfgAmmo
{

	class default
	{
	};

	class BulletSingle :default
	{
	};

	class BulletSniper :BulletSingle
	{
	};

	class BulletSniperE :BulletSniper
	{
	};

	class BulletSingleSVD :BulletSniperE
	{
		tracerColor[] = { 0.1,0.1,0.1,0.04 };
		tracerColorR[] = { 0,0,0,0.005 };
		visibleFire = 0.035;
		audibleFire = 0.035;
		visibleFireTime = 2;
		hit = 18;
	};

	class BulletSinglePTRD :BulletSingleSVD
	{
		tracerColor[] = { 0.9,0.9,0.1,0.04 };
		hit = 300;
	};

	class BulletSingleGL :BulletSingleSVD
	{
		tracerColor[] = { 0.1,0.9,0.1,0.04 };
		indirectHit = 18;
		indirectHitRange = 7;
		minRange = 40;
		minRangeProbab = 0.1;
		midRange = 45;
		midRangeProbab = 0.3;
		maxRange = 60;
		maxRangeProbab = 0.5;
		//model = "granat";
		//simulation = "shotShell";
		//explosive = 1;
	};
};

class CfgWeapons
{

	class Default
	{
	};

	class MGun :Default
	{
	};

	class Riffle :MGun
	{
	};

	class SniperRiffle :Riffle
	{
	};

	class SVDBase :SniperRiffle
	{
		scopeWeapon = 2;
		scopeMagazine = 2;
		model = "SVD_dragunov_proxy";
		modelOptics = "optika_snpiere";
		count = 9999;
		ammo = "BulletSingleSVD";
		opticsZoomMin = 0.04;
		opticsZoomMax = 0.04;
		distanceZoomMin = 300;
		distanceZoomMax = 300;
		displayName = "SVD Silenced";
		displayNameMagazine = "SVD Silenced Mag.";
		shortNameMagazine = "SVD Silenced Mag.";
		initSpeed = 10000; //
		modes[] = { "Single","PTRD","GL" };

		class Single
		{
			displayName = "SVD";
			ammo = "BulletSingleSVD";
			multiplier = 1;
			burst = 1;

			//dispersion = 0.00003;
			dispersion = 0.0;

			sound[] = { "Weapons\hk_singleshot",0.0003162,1 };
			soundContinuous = 0;
			reloadTime = 0.03;
			ffCount = 1;

			//recoil = "sniperSingle";
			recoil = "SDVZero";

			autoFire = 0;
			aiRateOfFire = 5;
			aiRateOfFireDistance = 500;
			useAction = 0;
			useActionTitle = "";
		};

		class PTRD
		{
			displayName = "PTRD";
			ammo = "BulletSinglePTRD";
			multiplier = 1;
			burst = 1;

			//dispersion = 0.00003;
			dispersion = 0.0;

			sound[] = { "Weapons\m21",0.0003162,1 };
			soundContinuous = 0;
			reloadTime = 0.03;
			ffCount = 1;

			//recoil = "sniperSingle";
			recoil = "SDVZero";

			autoFire = 0;
			aiRateOfFire = 5;
			aiRateOfFireDistance = 100;
			useAction = 0;
			useActionTitle = "";
		};

		class GL
		{
			displayName = "GP-25";
			ammo = "BulletSingleGL";
			multiplier = 1;
			burst = 1;
			dispersion = 0.0;
			sound[] = { "weapons\M16GrenadeLaunch",0.0003162,1 };
			soundContinuous = 0;
			reloadTime = 0.03;
			ffCount = 1;

			//recoil = "sniperSingle";
			recoil = "SDVZero";

			autoFire = 0;
			aiRateOfFire = 5;
			aiRateOfFireDistance = 1;
			useAction = 0;
			useActionTitle = "";
		};
	};

	class SVDMag :SVDBase
	{
		scopeMagazine = 2;
		picture = "\svd\m_svd.paa";
	};

	class SVD :SVDBase
	{
		scopeWeapon = 2;
		magazines[] = { "SVDmag" };
		picture = "\svd\w_svd.paa";
	};
};

class CfgVehicles
{

	class All
	{
	};

	class AllVehicles :All
	{
	};

	class Land :AllVehicles
	{
	};

	class Man :Land
	{
	};

	class Soldier :Man
	{
	};

};

class CfgNonAIVehicles
{

	class ProxyWeapon
	{
	};

	class ProxySVD :ProxyWeapon
	{
	};

};

class CfgRecoils
{
	SDVZero[] = { 0, 0, 0, 0, 0, 0 };
};

